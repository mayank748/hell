export const cameravideooff=require("../assets/cameravideooff.svg");
export const mic=require("../assets/mic.svg");
export const micmute=require("../assets/micmute.svg");
export const cameravideo=require("../assets/cameravideo.svg");